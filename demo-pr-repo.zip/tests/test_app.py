"""Тесты для демо-модуля."""
import pytest

from app import apply_discount, greet


def test_greet_default():
    assert greet() == "Привет, мир!"


def test_greet_name():
    assert greet("Алиса") == "Привет, Алиса!"


def test_discount():
    assert apply_discount(200.0, 25) == 150.0


def test_discount_invalid():
    with pytest.raises(ValueError):
        apply_discount(100.0, 150)
